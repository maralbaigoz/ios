// ShoppingCartAssignment.swift
// Complete implementation for the Shopping Cart System Assignment
// Single-file Swift Playground / Swift file you can paste into an Xcode Playground

import Foundation

// MARK: - Errors

enum ProductError: Error {
    case invalidPrice
}

enum CartItemError: Error {
    case invalidQuantity
}

// MARK: - Product (struct)

struct Product: Codable, Equatable {
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String

    enum Category: String, Codable {
        case electronics
        case clothing
        case food
        case books
    }

    /// Computed property to display price as currency string
    var displayPrice: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        // Uses current locale by default. If you need USD specifically, set currencyCode.
        return formatter.string(from: NSNumber(value: price)) ?? "\(price)"
    }

    /// Failable initializer that validates price > 0
    init?(id: String = UUID().uuidString, name: String, price: Double, category: Category, description: String = "") {
        guard price >= 0 else { return nil }
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}

// MARK: - CartItem (struct)

struct CartItem: Codable, Equatable {
    let product: Product
    private(set) var quantity: Int

    init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = max(1, quantity)
    }

    var subtotal: Double {
        return product.price * Double(quantity)
    }

    mutating func updateQuantity(_ newQuantity: Int) throws {
        guard newQuantity > 0 else { throw CartItemError.invalidQuantity }
        self.quantity = newQuantity
    }

    mutating func increaseQuantity(by amount: Int) throws {
        guard amount > 0 else { throw CartItemError.invalidQuantity }
        self.quantity += amount
    }
}

// MARK: - Discount system (simple mapping + extensible enum)

enum DiscountType {
    case percentage(Double)   // e.g. 0.10 = 10%
    case fixedAmount(Double)  // e.g. 5.0 = $5 off
}

// Helper to resolve discount codes to DiscountType
fileprivate func discountFor(code: String?) -> DiscountType? {
    guard let code = code else { return nil }
    switch code.uppercased() {
    case "SAVE10": return .percentage(0.10)
    case "SAVE20": return .percentage(0.20)
    case "TAKE5":  return .fixedAmount(5.0)
    default: return nil
    }
}

// MARK: - ShoppingCart (class)

class ShoppingCart {
    private(set) var items: [CartItem]
    var discountCode: String?

    init(items: [CartItem] = []) {
        self.items = items
    }

    /// Add item to cart. If product already exists, increase its quantity.
    func addItem(product: Product, quantity: Int = 1) {
        guard quantity > 0 else { return }
        if let index = items.firstIndex(where: { $0.product.id == product.id }) {
            // value type: get, modify, assign back
            var existing = items[index]
            do {
                try existing.increaseQuantity(by: quantity)
                items[index] = existing
            } catch {
                // invalid quantity - ignore
            }
        } else {
            let newItem = CartItem(product: product, quantity: quantity)
            items.append(newItem)
        }
    }

    func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }

    func updateItemQuantity(productId: String, quantity: Int) {
        guard quantity >= 0 else { return }
        if let index = items.firstIndex(where: { $0.product.id == productId }) {
            if quantity == 0 {
                removeItem(productId: productId)
            } else {
                var item = items[index]
                do {
                    try item.updateQuantity(quantity)
                    items[index] = item
                } catch {
                    // invalid quantity - ignore
                }
            }
        }
    }

    func clearCart() {
        items.removeAll()
        discountCode = nil
    }

    var subtotal: Double {
        return items.reduce(0) { $0 + $1.subtotal }
    }

    var discountAmount: Double {
        guard let discount = discountFor(code: discountCode) else { return 0 }
        switch discount {
        case .percentage(let pct):
            return subtotal * pct
        case .fixedAmount(let amount):
            return min(amount, subtotal)
        }
    }

    var total: Double {
        return max(0, subtotal - discountAmount)
    }

    var itemCount: Int {
        return items.reduce(0) { $0 + $1.quantity }
    }

    var isEmpty: Bool {
        return items.isEmpty
    }
}

// MARK: - Address (struct)

struct Address: Codable, Equatable {
    let street: String
    let city: String
    let zipCode: String
    let country: String

    var formattedAddress: String {
        return "\(street)\n\(city), \(zipCode)\n\(country)"
    }
}

// MARK: - Order (struct)

struct Order: Codable {
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address

    init(from cart: ShoppingCart, shippingAddress: Address) {
        self.orderId = UUID().uuidString
        // copy current state of cart
        self.items = cart.items
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }

    var itemCount: Int {
        return items.reduce(0) { $0 + $1.quantity }
    }
}

// MARK: - Bonus: User class

class User {
    let userId: String
    let name: String
    let email: String
    private(set) var orderHistory: [Order]

    init(userId: String = UUID().uuidString, name: String, email: String) {
        self.userId = userId
        self.name = name
        self.email = email
        self.orderHistory = []
    }

    func placeOrder(_ order: Order) {
        orderHistory.append(order)
    }

    var totalSpent: Double {
        return orderHistory.reduce(0) { $0 + $1.total }
    }
}

// MARK: - Tests / Demonstration

func runTests() {
    print("--- Shopping Cart Assignment Tests ---")

    // 1. Create sample products
    guard let laptop = Product(name: "Laptop Pro", price: 1299.99, category: .electronics, description: "Powerful laptop") else {
        print("Failed to create laptop")
        return
    }
    guard let book = Product(name: "Swift Programming", price: 39.99, category: .books, description: "Learn Swift") else {
        print("Failed to create book")
        return
    }
    guard let headphones = Product(name: "Headphones", price: 199.99, category: .electronics, description: "Noise cancelling") else {
        print("Failed to create headphones")
        return
    }

    print("Products created:")
    print("- \(laptop.name): \(laptop.displayPrice)")
    print("- \(book.name): \(book.displayPrice)")
    print("- \(headphones.name): \(headphones.displayPrice)")

    // 2. Test adding items to cart
    let cart = ShoppingCart()
    cart.addItem(product: laptop, quantity: 1)
    cart.addItem(product: book, quantity: 2)
    print("After adding laptop and 2 books: itemCount=\(cart.itemCount), subtotal=\(String(format: "%.2f", cart.subtotal))")

    // 3. Test adding same product twice
    cart.addItem(product: laptop, quantity: 1)
    if let laptopItem = cart.items.first(where: { $0.product.id == laptop.id }) {
        print("Laptop quantity after adding again: \(laptopItem.quantity) (expected 2)")
    }

    // 4. Test cart calculations
    print("Subtotal: \(String(format: "%.2f", cart.subtotal))")
    print("Item count: \(cart.itemCount)")

    // 5. Test discount code
    cart.discountCode = "SAVE10"
    print("Discount amount: \(String(format: "%.2f", cart.discountAmount))")
    print("Total with discount: \(String(format: "%.2f", cart.total))")

    // 6. Test removing items
    cart.removeItem(productId: book.id)
    print("After removing book: itemCount=\(cart.itemCount), subtotal=\(String(format: "%.2f", cart.subtotal))")

    // 7. Demonstrate REFERENCE TYPE behavior
    func modifyCart(_ cart: ShoppingCart) {
        cart.addItem(product: headphones, quantity: 1)
    }
    modifyCart(cart)
    print("After modifyCart: itemCount=\(cart.itemCount) (headphones added)")

    // 8. Demonstrate VALUE TYPE behavior
    var item1 = CartItem(product: laptop, quantity: 1)
    var item2 = item1
    try? item2.updateQuantity(5)
    print("item1.quantity=\(item1.quantity) (expected 1), item2.quantity=\(item2.quantity) (expected 5)")

    // 9. Create order from cart
    let address = Address(street: "123 Main St", city: "Almaty", zipCode: "050000", country: "Kazakhstan")
    let order = Order(from: cart, shippingAddress: address)
    print("Order created with \(order.itemCount) items, total=\(String(format: "%.2f", order.total))")

    // 10. Modify cart after order creation
    cart.clearCart()
    print("After clearing cart: cart.itemCount=\(cart.itemCount), order.itemCount=\(order.itemCount) (order should be unchanged)")

    // Bonus: User and placing order
    let user = User(name: "Maral Bay", email: "maral@example.com")
    user.placeOrder(order)
    print("User order history count=\(user.orderHistory.count), totalSpent=\(String(format: "%.2f", user.totalSpent))")

    print("--- Tests complete ---")
}

// Run tests when file is executed in Playground
runTests()

/*
 README (short, included as comment)

 Why ShoppingCart is a class:
 - ShoppingCart represents shared mutable state in the application. Multiple parts of an app (view controllers, view models) can hold references to the same cart and expect that mutations are visible to all. That necessitates reference semantics provided by a class.

 Why Product and Order are structs:
 - Product and Order are value types without identity requirements. Product is pure data that can be copied safely. Order is an immutable snapshot of the cart at checkout time, so representing it as a struct with constant properties ensures it cannot be changed after creation.

 Example where reference semantics matter:
 - When you pass ShoppingCart into a function that adds an item, the original cart should change. Using a class allows that behavior naturally.

 Example where value semantics matter:
 - CartItem is a struct: copying it and modifying the copy should not affect the original, illustrating value semantics.

 Challenges & solutions:
 - Validating inputs (price, quantity): used failable initializer for Product and guards in CartItem methods. For discounts, used a simple resolver function that can be extended.

*/

