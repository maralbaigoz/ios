
import Foundation

// Errors

enum ProductError: Error {
    case invalidPrice
}

enum CartItemError: Error {
    case invalidQuantity
}

// Product (struct)

struct Product: Codable, Equatable {
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String

    enum Category: String, Codable {
        case electronics
        case clothing
        case food
        case books
    }

    
    var displayPrice: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        
        return formatter.string(from: NSNumber(value: price)) ?? "\(price)"
    }

    
    init?(id: String = UUID().uuidString, name: String, price: Double, category: Category, description: String = "") {
        guard price >= 0 else { return nil }
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}

//  - CartItem (struct)

struct CartItem: Codable, Equatable {
    let product: Product
    private(set) var quantity: Int

    init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = max(1, quantity)
    }

    var subtotal: Double {
        return product.price * Double(quantity)
    }

    mutating func updateQuantity(_ newQuantity: Int) throws {
        guard newQuantity > 0 else { throw CartItemError.invalidQuantity }
        self.quantity = newQuantity
    }

    mutating func increaseQuantity(by amount: Int) throws {
        guard amount > 0 else { throw CartItemError.invalidQuantity }
        self.quantity += amount
    }
}

//  Discount system (simple mapping + ex enum)

enum DiscountType {
    case percentage(Double)   // e.g. 0.10 = 10%
    case fixedAmount(Double)  // e.g. 5.0 = $5 off
}

// Helper to resolve discount codes to DiscountType
fileprivate func discountFor(code: String?) -> DiscountType? {
    guard let code = code else { return nil }
    switch code.uppercased() {
    case "SAVE10": return .percentage(0.10)
    case "SAVE20": return .percentage(0.20)
    case "TAKE5":  return .fixedAmount(5.0)
    default: return nil
    }
}

// - ShoppingCart (class)

class ShoppingCart {
    private(set) var items: [CartItem]
    var discountCode: String?

    init(items: [CartItem] = []) {
        self.items = items
    }

   
    func addItem(product: Product, quantity: Int = 1) {
        guard quantity > 0 else { return }
        if let index = items.firstIndex(where: { $0.product.id == product.id }) {
            
            var existing = items[index]
            do {
                try existing.increaseQuantity(by: quantity)
                items[index] = existing
            } catch {
               
            }
        } else {
            let newItem = CartItem(product: product, quantity: quantity)
            items.append(newItem)
        }
    }

    func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }

    func updateItemQuantity(productId: String, quantity: Int) {
        guard quantity >= 0 else { return }
        if let index = items.firstIndex(where: { $0.product.id == productId }) {
            if quantity == 0 {
                removeItem(productId: productId)
            } else {
                var item = items[index]
                do {
                    try item.updateQuantity(quantity)
                    items[index] = item
                } catch {
                    
                }
            }
        }
    }

    func clearCart() {
        items.removeAll()
        discountCode = nil
    }

    var subtotal: Double {
        return items.reduce(0) { $0 + $1.subtotal }
    }

    var discountAmount: Double {
        guard let discount = discountFor(code: discountCode) else { return 0 }
        switch discount {
        case .percentage(let pct):
            return subtotal * pct
        case .fixedAmount(let amount):
            return min(amount, subtotal)
        }
    }

    var total: Double {
        return max(0, subtotal - discountAmount)
    }

    var itemCount: Int {
        return items.reduce(0) { $0 + $1.quantity }
    }

    var isEmpty: Bool {
        return items.isEmpty
    }
}

//  - Address (struct)

struct Address: Codable, Equatable {
    let street: String
    let city: String
    let zipCode: String
    let country: String

    var formattedAddress: String {
        return "\(street)\n\(city), \(zipCode)\n\(country)"
    }
}

//  - Order (struct)

struct Order: Codable {
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address

    init(from cart: ShoppingCart, shippingAddress: Address) {
        self.orderId = UUID().uuidString
        // copy current state of cart
        self.items = cart.items
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }

    var itemCount: Int {
        return items.reduce(0) { $0 + $1.quantity }
    }
}

// Bonus: User class

class User {
    let userId: String
    let name: String
    let email: String
    private(set) var orderHistory: [Order]

    init(userId: String = UUID().uuidString, name: String, email: String) {
        self.userId = userId
        self.name = name
        self.email = email
        self.orderHistory = []
    }

    func placeOrder(_ order: Order) {
        orderHistory.append(order)
    }

    var totalSpent: Double {
        return orderHistory.reduce(0) { $0 + $1.total }
    }
}

// Tests

func runTests() {
    print("--- Shopping Cart Assignment Tests ---")

    
    guard let laptop = Product(name: "Laptop Pro", price: 1299.99, category: .electronics, description: "Powerful laptop") else {
        print("Failed to create laptop")
        return
    }
    guard let book = Product(name: "Swift Programming", price: 39.99, category: .books, description: "Learn Swift") else {
        print("Failed to create book")
        return
    }
    guard let headphones = Product(name: "Headphones", price: 199.99, category: .electronics, description: "Noise cancelling") else {
        print("Failed to create headphones")
        return
    }

    print("Products created:")
    print("- \(laptop.name): \(laptop.displayPrice)")
    print("- \(book.name): \(book.displayPrice)")
    print("- \(headphones.name): \(headphones.displayPrice)")

    
    let cart = ShoppingCart()
    cart.addItem(product: laptop, quantity: 1)
    cart.addItem(product: book, quantity: 2)
    print("After adding laptop and 2 books: itemCount=\(cart.itemCount), subtotal=\(String(format: "%.2f", cart.subtotal))")

    
    cart.addItem(product: laptop, quantity: 1)
    if let laptopItem = cart.items.first(where: { $0.product.id == laptop.id }) {
        print("Laptop quantity after adding again: \(laptopItem.quantity) (expected 2)")
    }

    
    print("Subtotal: \(String(format: "%.2f", cart.subtotal))")
    print("Item count: \(cart.itemCount)")

    
    cart.discountCode = "SAVE10"
    print("Discount amount: \(String(format: "%.2f", cart.discountAmount))")
    print("Total with discount: \(String(format: "%.2f", cart.total))")

  
    cart.removeItem(productId: book.id)
    print("After removing book: itemCount=\(cart.itemCount), subtotal=\(String(format: "%.2f", cart.subtotal))")

    
    func modifyCart(_ cart: ShoppingCart) {
        cart.addItem(product: headphones, quantity: 1)
    }
    modifyCart(cart)
    print("After modifyCart: itemCount=\(cart.itemCount) (headphones added)")

   
    var item1 = CartItem(product: laptop, quantity: 1)
    var item2 = item1
    try? item2.updateQuantity(5)
    print("item1.quantity=\(item1.quantity) (expected 1), item2.quantity=\(item2.quantity) (expected 5)")

    
    let address = Address(street: "123 Main St", city: "Almaty", zipCode: "050000", country: "Kazakhstan")
    let order = Order(from: cart, shippingAddress: address)
    print("Order created with \(order.itemCount) items, total=\(String(format: "%.2f", order.total))")

    
    cart.clearCart()
    print("After clearing cart: cart.itemCount=\(cart.itemCount), order.itemCount=\(order.itemCount) (order should be unchanged)")

    
    let user = User(name: "Maral Baigoz", email: "maral@gmail.com")
    user.placeOrder(order)
    print("User order history count=\(user.orderHistory.count), totalSpent=\(String(format: "%.2f", user.totalSpent))")

    print("--- Tests dodne ---")
}


runTests()


 

