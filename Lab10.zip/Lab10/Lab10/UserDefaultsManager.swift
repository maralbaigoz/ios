//
//  UserDefaultsManager.swift
//  Lab10
//
//  Created by Alpamys Issamadi on 12/4/25.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()
    private let lastHeroIdKey = "lastHeroId"
    
    private init() {}
    
    func saveLastHeroId(_ id: Int) {
        UserDefaults.standard.set(id, forKey: lastHeroIdKey)
    }
    
    func getLastHeroId() -> Int? {
        let id = UserDefaults.standard.integer(forKey: lastHeroIdKey)
        return id > 0 ? id : nil
    }
}

