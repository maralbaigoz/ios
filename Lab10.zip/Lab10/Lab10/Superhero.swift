//
//  Superhero.swift
//  Lab10
//
//  Created by Alpamys Issamadi on 12/4/25.
//

import Foundation

struct Superhero: Codable {
    let id: Int
    let name: String
    let powerstats: PowerStats
    let appearance: Appearance
    let biography: Biography
    let images: Images
}

struct PowerStats: Codable {
    let intelligence: Int
    let strength: Int
    let speed: Int
    let durability: Int
    let power: Int
    let combat: Int
}

struct Appearance: Codable {
    let gender: String?
    let race: String?
}

struct Biography: Codable {
    let fullName: String?
    let placeOfBirth: String?
    let alignment: String?
}

struct Images: Codable {
    let xs: String?
    let sm: String?
    let md: String?
    let lg: String?
}
