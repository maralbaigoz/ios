//
//  ViewController.swift
//  Lab10
//
//  Created by Alpamys Issamadi on 12/4/25.
//

import UIKit
import Kingfisher

class ViewController: UIViewController {
    
    // MARK: - IBOutlets
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var heroImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var intelligenceLabel: UILabel!
    @IBOutlet weak var strengthLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var durabilityLabel: UILabel!
    @IBOutlet weak var combatLabel: UILabel!
    @IBOutlet weak var raceLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var placeOfBirthLabel: UILabel!
    @IBOutlet weak var alignmentLabel: UILabel!
    @IBOutlet weak var randomizeButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    // MARK: - Properties
    private var currentHero: Superhero?
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadLastHeroOrRandom()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = "Superhero Randomizer"
        randomizeButton.setTitle("Randomize", for: .normal)
        activityIndicator.hidesWhenStopped = true
    }
    
    // MARK: - Actions
    @IBAction func randomizeButtonTapped(_ sender: UIButton) {
        fetchRandomHero()
    }
    
    // MARK: - Methods
    private func loadLastHeroOrRandom() {
        if let lastHeroId = UserDefaultsManager.shared.getLastHeroId() {
            loadHeroById(lastHeroId)
        } else {
            fetchRandomHero()
        }
    }
    
    private func loadHeroById(_ id: Int) {
        activityIndicator.startAnimating()
        randomizeButton.isEnabled = false
        
        SuperheroService.shared.getHeroById(id) { [weak self] result in
            DispatchQueue.main.async {
                self?.activityIndicator.stopAnimating()
                self?.randomizeButton.isEnabled = true
                
                switch result {
                case .success(let hero):
                    self?.displayHero(hero)
                case .failure(let error):
                    self?.showError(error.localizedDescription)
                    self?.fetchRandomHero()
                }
            }
        }
    }
    
    private func fetchRandomHero() {
        activityIndicator.startAnimating()
        randomizeButton.isEnabled = false
        
        SuperheroService.shared.getRandomHero { [weak self] result in
            DispatchQueue.main.async {
                self?.activityIndicator.stopAnimating()
                self?.randomizeButton.isEnabled = true
                
                switch result {
                case .success(let hero):
                    self?.displayHero(hero)
                    UserDefaultsManager.shared.saveLastHeroId(hero.id)
                case .failure(let error):
                    self?.showError(error.localizedDescription)
                }
            }
        }
    }
    
    private func displayHero(_ hero: Superhero) {
        currentHero = hero
        
        // Загрузка изображения
        if let imageURLString = hero.images.md ?? hero.images.lg ?? hero.images.sm,
           let imageURL = URL(string: imageURLString) {
            heroImageView.kf.setImage(with: imageURL, placeholder: UIImage(systemName: "person.fill"))
        } else {
            heroImageView.image = UIImage(systemName: "person.fill")
        }
        
        // Отображение информации
        nameLabel.text = "Name: \(hero.name)"
        fullNameLabel.text = "Full Name: \(hero.biography.fullName ?? "Unknown")"
        intelligenceLabel.text = "Intelligence: \(hero.powerstats.intelligence)"
        strengthLabel.text = "Strength: \(hero.powerstats.strength)"
        speedLabel.text = "Speed: \(hero.powerstats.speed)"
        powerLabel.text = "Power: \(hero.powerstats.power)"
        durabilityLabel.text = "Durability: \(hero.powerstats.durability)"
        combatLabel.text = "Combat: \(hero.powerstats.combat)"
        raceLabel.text = "Race: \(hero.appearance.race ?? "Unknown")"
        genderLabel.text = "Gender: \(hero.appearance.gender ?? "Unknown")"
        placeOfBirthLabel.text = "Place of Birth: \(hero.biography.placeOfBirth ?? "Unknown")"
        alignmentLabel.text = "Alignment: \(hero.biography.alignment ?? "Unknown")"
    }
    
    private func showError(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
