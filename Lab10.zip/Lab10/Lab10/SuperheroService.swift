//
//  SuperheroService.swift
//  Lab10
//
//  Created by Alpamys Issamadi on 12/4/25.
//

import Foundation
import Alamofire

class SuperheroService {
    static let shared = SuperheroService()
    private let baseURL = "https://akabab.github.io/superhero-api/api"
    private let decoder = JSONDecoder()
    
    private init() {}
    
    func getAllHeroes(completion: @escaping (Result<[Superhero], Error>) -> Void) {
        let url = "\(baseURL)/all.json"
        
        AF.request(url).responseData { response in
            switch response.result {
            case .success(let data):
                do {
                    let heroes = try self.decoder.decode([Superhero].self, from: data)
                    completion(.success(heroes))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func getRandomHero(completion: @escaping (Result<Superhero, Error>) -> Void) {
        getAllHeroes { result in
            switch result {
            case .success(let heroes):
                if let randomHero = heroes.randomElement() {
                    completion(.success(randomHero))
                } else {
                    completion(.failure(NSError(domain: "SuperheroService", code: -1, userInfo: [NSLocalizedDescriptionKey: "No heroes found"])))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func getHeroById(_ id: Int, completion: @escaping (Result<Superhero, Error>) -> Void) {
        let url = "\(baseURL)/id/\(id).json"
        
        AF.request(url).responseData { response in
            switch response.result {
            case .success(let data):
                do {
                    let hero = try self.decoder.decode(Superhero.self, from: data)
                    completion(.success(hero))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}

